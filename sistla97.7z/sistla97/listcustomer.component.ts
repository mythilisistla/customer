import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/model/customer';
import { CustomerService } from 'src/app/service/customer.service';

@Component({
  selector: 'app-listcustomer',
  templateUrl: './listcustomer.component.html',
  styleUrls: ['./listcustomer.component.css']
})
export class ListcustomerComponent implements OnInit {
customers:Customer[];
  constructor(private customerService:CustomerService) { }

  ngOnInit() {
    this.customerService.getCustomers().
    subscribe((data:Customer[])=>{this.customers=data
    console.log(this.customers+" "+this.customerService.getCustomers.length);
  });
  }
  deleteCustomer(customer:Customer)
{
  console.log("Delete");
  this.customerService.deleteCustomer(customer).subscribe((data)=>{
    this.customers=this.customers.filter(c=>c!==customer);
  });
}}
