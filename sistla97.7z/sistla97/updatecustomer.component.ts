import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/service/customer.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Customer } from 'src/app/model/customer';

@Component({
  selector: 'app-updatecustomer',
  templateUrl: './updatecustomer.component.html',
  styleUrls: ['./updatecustomer.component.css']
})
export class UpdatecustomerComponent implements OnInit {
customerData:Customer={"id":'',"name":'',"email":'',"phone":0};
  constructor(private customerService:CustomerService,private router:Router,private route:ActivatedRoute) {

   }

  ngOnInit() {
    this.route.params.subscribe((params=>{this.customerService.getById(params['id']).subscribe(res=>{this.customerData=res;
    });

  }));

}
}
