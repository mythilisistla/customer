import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'customercrud';
  //name:string="mythili";
//dob=new Date(1997,5,5);
//salary=21186;
}
