import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListcustomerComponent } from './comps/listcustomer/listcustomer.component';
import { ContactComponent } from './comps/contact/contact.component';
import { AboutComponent } from './comps/about/about.component';
import { UpdatecustomerComponent } from './comps/updatecustomer/updatecustomer.component';
import { AddcustomerComponent } from './comps/addcustomer/addcustomer.component';

const routes: Routes = [
  {path:'listcustomer',component:ListcustomerComponent},
  {path:'addcustomer',component:AddcustomerComponent},
  {path:'updatecustomer/:id',component:UpdatecustomerComponent},
  {path:'about',component:AboutComponent},
  {path:'contact',component:ContactComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
