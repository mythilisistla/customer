import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule,FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {CustomerService} from './service/customer.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListcustomerComponent } from './comps/listcustomer/listcustomer.component';
import { AddcustomerComponent } from './comps/addcustomer/addcustomer.component';
import { UpdatecustomerComponent } from './comps/updatecustomer/updatecustomer.component';
import { AboutComponent } from './comps/about/about.component';
import { ContactComponent } from './comps/contact/contact.component';


@NgModule({
  declarations: [                                                                                                                            
    AppComponent,
    ListcustomerComponent,
    AddcustomerComponent,
    UpdatecustomerComponent,
    AboutComponent,
    ContactComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
